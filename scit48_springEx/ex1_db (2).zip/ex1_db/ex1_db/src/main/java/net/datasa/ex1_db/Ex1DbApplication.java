package net.datasa.ex1_db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex1DbApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex1DbApplication.class, args);
	}

}
