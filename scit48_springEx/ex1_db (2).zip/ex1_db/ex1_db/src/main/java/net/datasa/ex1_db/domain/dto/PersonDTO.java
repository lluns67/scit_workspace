package net.datasa.ex1_db.domain.dto;

import lombok.Data;

@Data
public class PersonDTO {
	private String id;
	private String name;
	private Integer age;
}
