package net.datasa.ex1_db.service;

import org.springframework.stereotype.Service;

@Service
public interface TestService {
	void testlog();
}
