package net.datasa.ex1_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex1DbApplicationTests {

	@Test
	void contextLoads() {
	}

}
