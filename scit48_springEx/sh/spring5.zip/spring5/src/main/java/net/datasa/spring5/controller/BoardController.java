package net.datasa.spring5.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.datasa.spring5.domain.dto.BoardDTO;
import net.datasa.spring5.service.BoardService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import org.springframework.ui.Model;
import jakarta.persistence.PrePersist;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * 게시판 관련 컨트롤러
 */
@Controller
@Slf4j
@RequiredArgsConstructor
@RequestMapping("board")
public class BoardController {
    private final BoardService bs;

    // application.properties 파일의 설정값.
    @Value("${board.pageSize}")
    int pageSize;

    @Value("${board.linkSize}")
    int linkSize;

    @Value("${board.uploadPath}")
    String uploadPath;

    /**
     * 글쓰기 페이지로 이동
     * 
     * @return writeForm.html
     */

    @GetMapping("write")
    public String write() {
        return "boardView/writeForm";
    }

    /**
     * 글 저장
     * 
     * @param boardDTO 작성한 글 정보
     * @param user     로그인한 사용자 정보
     * @param upload   첨부파일
     * @return 게시판 글 목록 경로
     */
    @PreAuthorize("isAuthenticated()")
    @PostMapping("write")
    public String write(BoardDTO boardDTO,
            @AuthenticationPrincipal UserDetails user,
            @RequestParam(name = "upload", required = false) MultipartFile upload) {

        // 작성한 글 정보에 사용자 아이디 추가
        boardDTO.setMemberId(user.getUsername());
        log.debug("저장할 글 정보 : {}", boardDTO);

        // 업로드된 첨부파일
        if (upload != null) {
            log.debug("Empty : {}", upload.isEmpty());
            log.debug("파라미터 이름 : {}", upload.getName());
            log.debug("파일명 : {}", upload.getOriginalFilename());
            log.debug("파일크기 : {}", upload.getSize());
            log.debug("파일종류 : {}", upload.getContentType());
        }

        try {
            bs.write(boardDTO, uploadPath, upload);
        } catch (Exception e) {
            log.debug("예외 발생 {}", e.getMessage());
            return "boardView/writeForm";
        }

        return "redirect:/"; // 임시
    }

    @GetMapping("listAll")
    public String listAll(Model model) {
        List<BoardDTO> dtoList = bs.getListAll();

        model.addAttribute("listAll", dtoList);

        return "boardView/listAll";
    }

}
