package net.datasa.spring5.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import net.datasa.spring5.domain.entity.BoardEntity;

/**
 * 게시판 관련 Repository
 */
@Repository
public interface BoardRepository extends JpaRepository<BoardEntity, Integer> {

    // JPQL : 직접 쿼리문을 입력
    // join fetch를 쓰면 N+1 문제를 방지할 수 있음.
    @Query("""
            select b
            from BoardEntity b
            join fetch b.member
            order by b.boardNum desc
            """)
    List<BoardEntity> findAllWithMemberOrderByBoardNumDesc();

}
