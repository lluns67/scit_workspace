package net.datasa.spring5.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.datasa.spring5.controller.AdminController;
import net.datasa.spring5.domain.dto.BoardDTO;
import net.datasa.spring5.domain.entity.BoardEntity;
import net.datasa.spring5.domain.entity.MemberEntity;
import net.datasa.spring5.repository.BoardRepository;
import net.datasa.spring5.repository.MemberRepository;
import net.datasa.spring5.repository.ReplyRepository;
import net.datasa.spring5.util.FileManager;

/**
 * 게시판 관련 서비스
 */
@Service
@Slf4j
@Transactional
@RequiredArgsConstructor
public class BoardService {

    private final AdminController adminController;

    private final MemberRepository mr;
    private final BoardRepository br;
    private final ReplyRepository rr;
    private final FileManager fm;

    // BoardService(AdminController adminController) {
    // this.adminController = adminController;
    // }

    /**
     * 게시글 저장
     * 
     * @param boardDTO   저장할 글 정보
     * @param uploadPath 파일 저장할 경로
     * @param upload     업로드된 파일
     */
    @Transactional(rollbackOn = IOException.class)
    public void write(BoardDTO boardDTO, String uploadPath, MultipartFile upload) throws IOException {
        // originalName, fileName <- 얘도 같이 저장해야 함.
        // fileName = fm.saveFile(경로, 첨부파일)

        MemberEntity memberEntity = mr.findById(boardDTO.getMemberId())
                .orElseThrow(
                        () -> new EntityNotFoundException("회원아이디가 없습니다."));

        BoardEntity entity = BoardEntity.builder()
                .member(memberEntity)
                .title(boardDTO.getTitle())
                .contents(boardDTO.getContents())
                .build();

        // 첨부파일이 있는 경우
        if (upload != null && !upload.isEmpty()) {
            String fileName = fm.saveFile(uploadPath, upload);
            entity.setFileName(fileName);
            entity.setOriginalName(upload.getOriginalFilename());
        }

        br.save(entity);
    }

    public List<BoardDTO> getListAll() {
        // 1.
        // Sort sort = Sort.by(Sort.Direction.DESC, "boardNum");
        // List<BoardEntity> entityList = br.findAll(sort);

        // 2.
        List<BoardEntity> entityList = br.findAllWithMemberOrderByBoardNumDesc();

        List<BoardDTO> dtoList = new ArrayList<>();

        for (BoardEntity entity : entityList) {
            BoardDTO dto = new BoardDTO();
            dto.setBoardNum(entity.getBoardNum());
            dto.setTitle(entity.getTitle());
            dto.setMemberId(entity.getMember().getMemberId());
            dto.setViewCount(entity.getViewCount());
            dto.setCreateDate(entity.getCreateDate());
            // BoardDTO dto = BoardDTO.convertToBoardDTO(entity); 일일히 set하기 귀찮으면 이거 써도 됨
            dtoList.add(dto);
        }

        return dtoList;
    }

}
