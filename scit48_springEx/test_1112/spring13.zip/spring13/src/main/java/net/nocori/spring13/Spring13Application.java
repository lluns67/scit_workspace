package net.nocori.spring13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring13Application {

	public static void main(String[] args) {
		SpringApplication.run(Spring13Application.class, args);
	}

}
