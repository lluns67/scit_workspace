package net.nocori.spring13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring13ApplicationTests {

	@Test
	void contextLoads() {
	}

}
